title: The Naturalist by Andrew Mayne
date: 2018-11-11 20:38:07
tags: Andrew Mayne, The Naturalist
category: Crime, Thriller, Fiction
description: It is nothing new that I like to read books from which I can learn something or at least read about topics which fascinate me.
postTitle: The Naturalist by Andrew Mayne
---
![The Naturalist by Andrew Mayne](/images/the_naturalist_by_andrew_mayne.jpg)
It is nothing new that I like to read books from which I can learn something or at least read about topics which fascinate me. So I was more than intrigued and not at all annoyed by the main character in book The Naturalist by Andrew Mayne - <b>professor Theo Cray, a computational biologist</b>, which strange title always makes people confused.<!-- more -->
But his field of expertise is bioinformatics, a cross between computational science and biology. So <b>he is a genius who sees patterns where others don&#39;t see nothing</b> and he even developed a software program designed to sift through thousands of pieces of information in order to find patterns.
Sounds cool, right?
And it is really, especially that he becomes involved and suspect of murder of his former student and many more soon discovered bodies. In the deep wood of Montana suddenly Theo Cray lands in the middle of an investigation and when police blindly searches any clues he starts to see something what they strangely don&#39;t. 
That of course makes him suspect number one which doesn&#39;t help when you are genius scientist and bit autistic. What makes The Naturalist really hard to put down is that he doesn&#39;t stop trying to find the clues and that he is also lost in his searches. 
<b>Serial killers are fascinating and well known topics for the thriller readers</b> but when police doesn&#39;t suspect that those murders are made by one and instead treat them as a bear attacks, then this makes an amazing story which keeps me reading it.
<b>Theo Cray uses his scientific knowledge and his program to discover patterns</b> to find out how many people have actually been killed. There is a really good paced and not an ordinary book about finding a serial killer.
The Naturalist thanks to unique main character makes it clever and fascinating to read. Professor Theo Cray and his sense of accuracy makes this book fantastic page turner which I made me interested in this book in the first place.
You would think that the author Andrew Mayne has any scientific background and you can be surprise as much as I was that he is actually <b>writer and magician and reading his story I can tell that he really created a great job, pure magic in science.</b>

For all the funs of that kind of interesting writing there is very good news as The Naturalist has 3 parts already. First is a The Naturalist, Looking Glass second and Murder Theory last one.
So if you are tired of typical divorce or oh so experienced detectives in the crime books then <b>Theo Cray is a new hero</b>.


SYNOPSIS (Source: Goodreads.com)
Professor Theo Cray is trained to see patterns where others see chaos. So when mutilated bodies found deep in the Montana woods leave the cops searching blindly for clues, Theo sees something they missed. Something unnatural. Something only he can stop.

As a computational biologist, Theo is more familiar with digital code and microbes than the dark arts of forensic sleuthing. But a field trip to Montana suddenly lands him in the middle of an investigation into the bloody killing of one of his former students. As more details, and bodies, come to light, the local cops determine that the killer is either a grizzly gone rogue… or Theo himself. Racing to stay one step ahead of the police, Theo must use his scientific acumen to uncover the killer. Will he be able to become as cunning as the predator he hunts—before he becomes its prey?
