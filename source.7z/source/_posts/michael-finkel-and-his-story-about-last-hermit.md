title: MICHAEL FINKEL, STORY ON A LAST HERMIT
date: 2018-10-12 11:19:16
tags: [Michael Finkel, Last true Hermit]
category: [NonFiction]
---

## MICHAEL FINKEL AND HIS STORY ABOUT LAST HERMIT
![The Stranger in the Woods: The Extraordinary Story of the Last True Hermit by Michael Finkel](/images/strangerinthewood.jpg)
Imagine, that you have a beloved summer house by the lake, and for almost 30 years notoriously the food is lost as well as other objects of everyday use.
<!-- more -->
You becoming paranoid and frustrated. You talk to neighbours but they share the same experience and solution is found. They are either defeated or angry, some of them offer help to buy needed food and batteries, anything just to stop obscure breaking to their houses.
And now imagine a man, who <b>has been living in the woods for 27 years, totally alone</b>. He is there during the winter when it is hard to imagine anyone out there not to mention to sleep in the tent, without fireplace to not attract attention. He is totally dependent on food which he stole from summer houses nearby. He is there all year around although for him it is the moon and seasons changing tell the time passing.

<b>His name is Christopher Knight and he at the age of 20 gave up all</b>, what life might bring and quite spontaneously, as he states himself, walked into the woods. He hasn’t served in the army where he could learn all surviving technics but he comes from simply farmers family who value most their privacy. He learned on the go how to survive in the forest, was making observation of the nature, had time like anyone in the world, was very smart and had dream-like escape from civilisation.
<b>Christopher managed to spend 27 years in solitude</b>, he coped to survive brutal Maine winters out in the woods.

He was never sick, didn’t make a fire for a warm and comfort. He read a lot, kept his camping tidy and well organised, during 27 years in the woods he made minimal if none damage to the nature, while police inspecting his place during just 3 days made more demolish and spoils. He was wearing glasses and his eyesight get worse over the years but his hearing has got better. He moves in the woods like an animal without leaving any tracks, without making any sound. He abandon any walks in the winter for not making footmarks on the snow and to avoid frostbites on his foots and hands he walks only around his camping and keep himself busy with heavy tasks of keeping himself warm and to thaw the water and food.
<b>He is free but he suffers, he is quite often hungry and cold, but he chooses this life, life on his own conditions, away from others. He probably would continue to lead his life if not one remarkable fact, that he in order to survive needs to steal from people.</b>

Michael Finkel wrote a profound book about one truly hermit in the world. Hiring two professional fact-checkers who spend hundred hours of re-reading materials, there are no pseudonyms used in this book and no identifying details have been changed. <b>There is a true story of a Chris Knight and in the same time it is an universal tale gather human history of our attempts to find sense in a modern world.</b>
Author wonders how long a person is able to spend in solitude, is it hours or days? Is it still possible for modern society to be able to withdraw, to be able to spend time only with our thoughts?

This book left me thinking deep about our society like no other and about living life like one want to in the constant solitude. I highly recommend to read The Stranger in the Woods to stop to trying too hard to make our life value and just focus on that what is matter for us.

The Stranger in the Woods: The Extraordinary Story of the Last True Hermit by Michael Finkel