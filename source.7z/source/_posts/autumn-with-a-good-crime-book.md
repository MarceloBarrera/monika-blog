title: Autumn with a good crime book?
date: 2018-10-19 11:37:01
tags: [Autumn crime book, Jørn Lier Horst, Norskkrim, Norwegian crime book, Book review]
category: [Crime]
description: Nullpunkt by Jørn Lier Horst and Thomas Enger will not disappoint and make autumnal evening much more interesting.
postTitle: Autum with a good crime book?

---
![Nullpunkt by Jørn Lier Horst and Thomas Enger](/images/nullpunkt.jpg)
Nullpunkt by Jørn Lier Horst and Thomas Enger will not disappoint and make autumnal evening much more interesting.
<!-- more -->
Jørn Lier Horst and Thomas Enger are really good partners in crime and they wrote a great crime reading for autumn.
This time detective Alexander Blix joins his force with celebrity blogger Emma Ramm. He is experienced cap and she has a journalist intuition, also there is something what they have in common, but luckily Emma doesn&#39;t remember it.

They meet at the front of the house of sports icon Sonja Nordstrøm whom Emma was about to interview. But Sonja is not at home and this rises Emma’s suspicious. Soon enough police confirms disappearance of Sonja and immediately initiate investigation.
Very soon police discovers new trails and the inquisition begin to speed up with new evidence which indicate that killer is carefully selecting his victims and that he has a chronological order for them. The killer works methodical and seems to be one step ahead of the police. The hunting for a murderer takes on an unpredictable turn of events, thus providing much drama.
There is excellent cooperation between a journalist and police as well as the media chase for sensationalism. The fast action, remarkable figures and events from the media world of Oslo in the background, create a great reading for autumn evenings.

Nullpunkt av Jørn Lier Horst and Thomas Enger, 2018. So far only available in Norwegian.