---
title: About Me
date: 2018-10-17 11:10:32
comments: false
---
Hi, my name is Monika and I am an avid reader, constant dreamer and new technology lover. I am fascinated by the power of books, how they can change people’s life, give them perspective and also help in order to survive everyday reality.
I created this blog as I have a strong need to share and to discuss about books I am reading. I left my country 15 years ago and living abroad although it is the greatest things one can do to get broad perspective and enriched life with life experience I also experience that it is sometimes difficult to meet your beasts. Someone with whom I can talk about books.
I live in Norway now and although Norwegians are very fluent to speak English from my observations, they are not so happy to read books in English. And it is a shame, as many, too many, to be honest, books are not translated to Norwegian. I wish many of those books I read I could recommend to my Norwegian collegues and I do so, hoping that some publishing house would see interest in them.
Luckily I can read books in three languages (getting better and better in reading på norsk) which gives me wider perspective and of course open more posibilities.
I call myself global citizen as I believe that country where I was born should not label me for all my life. Neither my children, who speaks four languages at home. Yep, I live in bilingual family and Norway is the third country I live in.
