title: Madeline Miller Circe
date: 2018-11-01 22:31:50
tags: [Madeline Miller, Circe, Book review, Feminism]
category: [Fiction, Fantasy, Mythology, Retellings, Historical Fiction]
description: Madeleine Miller Circe, I really love the phenomenon in literature when one figure in the book is transferred to another book and there is gaining a new life.
postTitle: Powerful journey of courage and empowerment in Circe by Madaline Miller

---
![Circe by Madeline Miller](/images/circe_madeline_miller.jpg)
I really love the phenomenon in literature when **one figure in the book is transferred to another book and there is gaining a new life**. And being student of Classic Literature we spent whole days reading and wondered about every day life of deities as Zeus, Athena or Helios.
<!-- more --> 
I could also recall how exactly I was fascinated by the story of Patroclus in The Song of Achilles a few years ago and I was more than happy to immerse myself **in the story of Circe, the new book of Madaline Miller.**

I remembered that Circe was a first daughter of Helios and beautiful nymph Perse (daughter of Oceanos) but she wasn&#39;t neither favourite child nor the prettiest. In fact she was mocked by her sibling and parents and her weak voice, what she will learn later from Hermes, that "you sound like a mortal" was considered around deities as the most offensive of all.
But Madaline Miller gives Circe much more than a mortal&#39;s voice, she gives her **strong character**, although we learn about it together with evolving life of Circe. She spent a lot of time surrounded by Titans (her father and many uncles) and she observed that their vanity and futility has no end. She began to sympathise with humans, feeling admiration and pity towards Prometeus, falling in love with Glaucos and feeling completely lost and alone when he, after gaining immortality turns her down. Heartbroken, betrayed and full of rage Circe used witchcraft to transforms her rival nymph Scylla into the sea monster, who will plague sailors for generations.
**For using witchcraft as unworthy for use by gods she is exiled to Aiaia where she spent rest of her life.** 

On Aiaia, her island, Circe is discovering her power, learning spells but most of all she learns a lot about humans life. **From being unhappy in her youth she turns into heroine who builds her extraordinary will.** 
Life on Aiaia could be as a dull as life in exile could possibly be but not for Circe. During her life there, she turns into a woman **who is trying to find her true self and live the life on her own rules. It is a powerful journey of courage** and empowerment actual in nowadays.

"When I was born," she begins her tale, "the name for what I was did not exist."
This is the magnificent story of woman empowerment and infinite mother&#39;s love. 
Meeting Hermes, Daedalus and Odysseus making this story into captivating from start to finish and reading about transformation of Circe into heroine makes this story truly amazing.
**Having son with Odysseus making Circe fragile or close to humanity.** It can resonate with many if not everyone reading this story. Her love for son shifts from desperation to unconditional mother&#39;s love, who would do everything for her son to live. It turns out it gives Circe also extraordinary power and bravery and her feelings resonate close to human&#39;s dilemmas of single motherhood and fear for beloved son.

**Circe is a beautiful story about a woman finding herself**, about feeling the huge power and will, about looking for possibilities in life and not giving up. 
Knowing that gods sitting somewhere up there and laughing from human efforts makes us also reflect about actions and life itself. 
And what is the most important you don&#39;t need to have a big knowledge of the Greek myths to fully understand and enjoy this story.

Circe by Madaline Miller, 5/5 stars
